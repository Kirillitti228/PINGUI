/*
  PINGUI Firebase configuration
  Replace the placeholder values with the Web App config from:
  Firebase Console -> Project settings -> Your apps -> Web app.
  This config is public in a browser app. Never put service-account keys here.
*/
window.PINGUI_FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID_HERE",
  appId: "PASTE_APP_ID_HERE"
};
